import React from 'react';
import { Calendar, PhoneCall } from 'lucide-react';

interface NavbarProps {
  onOpenBooking: () => void;
  phone: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking, phone }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-purple-100/60 shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 lg:px-8 py-3.5">
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#top" 
          className="flex items-center gap-2.5 text-lg sm:text-xl font-bold tracking-tight text-purple-900 whitespace-nowrap shrink-0 group focus:outline-hidden focus-visible:ring-2 focus-visible:ring-teal-500 rounded-sm"
        >
          <span className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-purple-800 to-teal-600 text-white shadow-xs font-black text-sm">
            TF
          </span>
          <span className="font-extrabold tracking-tight">
            TU FARO <span className="text-teal-600 font-semibold">EN SALUD</span>
          </span>
        </a>

        {/* Zone 2: 4-5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <a 
            href="#especialidades" 
            className="hover:text-purple-800 transition-colors whitespace-nowrap shrink-0"
          >
            Especialidades
          </a>
          <a 
            href="#beneficios" 
            className="hover:text-purple-800 transition-colors whitespace-nowrap shrink-0"
          >
            Beneficios
          </a>
          <a 
            href="#autoridad" 
            className="hover:text-purple-800 transition-colors whitespace-nowrap shrink-0"
          >
            Experiencia
          </a>
          <a 
            href="#testimonios" 
            className="hover:text-purple-800 transition-colors whitespace-nowrap shrink-0"
          >
            Testimonios
          </a>
          <a 
            href="#contacto" 
            className="hover:text-purple-800 transition-colors whitespace-nowrap shrink-0"
          >
            Contacto
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={`tel:${phone.replace(/\s+/g, '')}`}
            className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-purple-900 hover:text-teal-700 transition-colors py-2 px-3 rounded-lg border border-purple-200/60 hover:border-teal-300"
            title="Llamar directamente"
          >
            <PhoneCall className="w-3.5 h-3.5 text-teal-600" />
            <span className="tabular-nums">{phone}</span>
          </a>

          <button
            onClick={onOpenBooking}
            type="button"
            className="inline-flex items-center gap-2 px-4 sm:px-5 py-2 text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-purple-700 to-teal-600 hover:from-purple-800 hover:to-teal-700 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 active:scale-98 whitespace-nowrap shrink-0 cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-teal-500"
          >
            <Calendar className="w-4 h-4" />
            <span>Pedir Cita</span>
          </button>
        </div>
      </div>
    </header>
  );
};
