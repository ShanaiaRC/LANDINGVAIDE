import React from 'react';
import { Phone, Mail, MapPin, Clock, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  phone: string;
  email: string;
  address: string;
  city: string;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  phone,
  email,
  address,
  city,
  onOpenBooking
}) => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          
          {/* Brand Col */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-md bg-gradient-to-br from-purple-700 to-teal-500 text-white flex items-center justify-center font-bold text-xs">
                TF
              </span>
              <span className="text-base font-extrabold text-white tracking-tight">
                TU FARO <span className="text-teal-400 font-semibold">EN SALUD</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Centro de Fisioterapia Especializada en Pediatría y Traumatología. Cuidado compasivo, riguroso e individualizado.
            </p>
            <div className="flex items-center gap-1.5 text-teal-400 font-medium text-xs pt-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Centro Sanitario Autorizado</span>
            </div>
          </div>

          {/* Especialidades */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Especialidades</h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li><a href="#beneficios" className="hover:text-teal-300 transition-colors">Fisioterapia Pediátrica</a></li>
              <li><a href="#beneficios" className="hover:text-teal-300 transition-colors">Cólicos y Plagiocefalia</a></li>
              <li><a href="#beneficios" className="hover:text-teal-300 transition-colors">Traumatología y Rehabilitación</a></li>
              <li><a href="#beneficios" className="hover:text-teal-300 transition-colors">Terapia Manual Ortopédica</a></li>
              <li><a href="#beneficios" className="hover:text-teal-300 transition-colors">Readaptación Funcional</a></li>
            </ul>
          </div>

          {/* Contacto & Ubicación */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Contacto Directo</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <a href={`tel:${phone.replace(/\s+/g, '')}`} className="hover:text-white transition-colors tabular-nums">{phone}</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <a href={`mailto:${email}`} className="hover:text-white transition-colors">{email}</a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                <span>{address}, {city}</span>
              </li>
            </ul>
          </div>

          {/* Horario y Reserva */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Horario de Consulta</h4>
            <div className="space-y-1 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>Lunes a Viernes: 09:00 - 20:30</span>
              </div>
              <p className="text-[11px] text-slate-500 pl-5.5">Cita previa obligatoria</p>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="w-full py-2 px-3 text-xs font-bold text-teal-300 bg-teal-950/60 border border-teal-500/30 rounded-lg hover:bg-teal-900/60 transition-colors cursor-pointer"
              >
                Solicitar Cita Previa Online
              </button>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} Tu Faro en Salud. Todos los derechos reservados.</p>
          <div className="flex items-center gap-4">
            <a href="#top" className="hover:text-slate-300 transition-colors">Aviso Legal</a>
            <span aria-hidden="true">·</span>
            <a href="#top" className="hover:text-slate-300 transition-colors">Privacidad y Protección de Datos</a>
            <span aria-hidden="true">·</span>
            <a href="#top" className="hover:text-slate-300 transition-colors">Política de Cookies</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
