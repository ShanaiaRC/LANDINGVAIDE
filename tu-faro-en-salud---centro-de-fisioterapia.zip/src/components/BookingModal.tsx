import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  Baby, 
  Activity, 
  CheckCircle2, 
  Send, 
  MessageCircle, 
  Sparkles,
  Link as LinkIcon,
  Phone,
  User,
  Mail,
  AlertCircle
} from 'lucide-react';
import { BookingData, ClinicConfig } from '../types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ClinicConfig;
  onUpdateConfig: (newConfig: ClinicConfig) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ 
  isOpen, 
  onClose,
  config,
  onUpdateConfig
}) => {
  const [formData, setFormData] = useState<BookingData>({
    service: 'pediatria',
    name: '',
    phone: '',
    email: '',
    preferredDate: '',
    preferredTime: 'tarde',
    notes: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showConfigDrawer, setShowConfigDrawer] = useState(false);
  const [tempCustomUrl, setTempCustomUrl] = useState(config.customDestinationUrl);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMessage('Por favor, indica tu nombre y teléfono de contacto para confirmar tu cita.');
      return;
    }

    setErrorMessage('');

    // If a custom destination URL is provided (e.g. payment link or Calendly), we can redirect
    if (config.customDestinationUrl && config.customDestinationUrl.trim() !== '') {
      window.open(config.customDestinationUrl, '_blank', 'noopener,noreferrer');
    }

    setIsSubmitted(true);
  };

  const handleSaveCustomLink = () => {
    onUpdateConfig({
      ...config,
      customDestinationUrl: tempCustomUrl.trim()
    });
    setShowConfigDrawer(false);
  };

  const generateWhatsAppUrl = () => {
    const serviceName = formData.service === 'pediatria' 
      ? 'Fisioterapia Pediátrica' 
      : formData.service === 'traumatologia' 
        ? 'Traumatología y Rehabilitación' 
        : 'Valoración General';

    const msg = `¡Hola Tu Faro en Salud! 👋 Acabo de solicitar cita previa:
• Paciente: ${formData.name}
• Especialidad: ${serviceName}
• Teléfono: ${formData.phone}
• Preferencia: ${formData.preferredDate || 'Próximos días'} (${formData.preferredTime === 'manana' ? 'Horario de Mañanas' : 'Horario de Tardes'})
• Motivo / Síntomas: ${formData.notes || 'Valoración inicial'}`;

    return `https://wa.me/${config.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      
      {/* Container */}
      <div 
        className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-purple-200 overflow-hidden my-8"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Modal Header */}
        <div className="relative px-6 py-5 bg-gradient-to-r from-purple-900 via-purple-800 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center text-teal-300">
              <Calendar className="w-4 h-4" />
            </span>
            <div>
              <h3 id="modal-title" className="text-lg font-bold text-white tracking-tight">
                {isSubmitted ? '¡Cita Solicitada con Éxito!' : 'Reserva Tu Cita Personalizada'}
              </h3>
              <p className="text-xs text-purple-200">
                Tu Faro en Salud · Pediatría y Traumatología
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Quick settings gear for custom link */}
            <button
              onClick={() => setShowConfigDrawer(!showConfigDrawer)}
              type="button"
              title="Configurar enlace de destino (pago / externo)"
              className="p-1.5 text-purple-200 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
            >
              <LinkIcon className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              type="button"
              className="p-1.5 text-purple-200 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              aria-label="Cerrar modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Optional Custom Destination URL Drawer */}
        {showConfigDrawer && (
          <div className="bg-purple-50 p-4 border-b border-purple-200 text-xs text-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-purple-900 flex items-center gap-1.5">
                <LinkIcon className="w-3.5 h-3.5 text-teal-600" />
                Personalizar Enlace de Destino (Link de pago / Formulario)
              </span>
              <button 
                onClick={() => setShowConfigDrawer(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                Cerrar
              </button>
            </div>
            <p className="text-slate-600">
              Si tienes un link de pago (Stripe, Bizum, etc.) o formulario externo, pégalo aquí para que el botón redirija automáticamente:
            </p>
            <div className="flex gap-2">
              <input
                type="url"
                value={tempCustomUrl}
                onChange={(e) => setTempCustomUrl(e.target.value)}
                placeholder="https://tupago.com o https://calendly.com/..."
                className="flex-1 px-3 py-1.5 text-xs bg-white rounded-md border border-slate-300 focus:outline-hidden focus:ring-1 focus:ring-teal-500"
              />
              <button
                onClick={handleSaveCustomLink}
                className="px-3 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-md transition-colors cursor-pointer"
              >
                Guardar
              </button>
            </div>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 sm:p-8">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Selector de Especialidad */}
              <div>
                <label className="block text-xs font-bold text-purple-950 uppercase tracking-wide mb-2">
                  1. Selecciona la Especialidad que necesitas:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, service: 'pediatria' })}
                    className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      formData.service === 'pediatria'
                        ? 'border-purple-600 bg-purple-50/70 ring-2 ring-purple-600/20'
                        : 'border-slate-200 hover:border-purple-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center shrink-0">
                      <Baby className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-purple-950">Fisioterapia Pediátrica</p>
                      <p className="text-[11px] text-slate-500">Cólicos, plagiocefalia, desarrollo motor</p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, service: 'traumatologia' })}
                    className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      formData.service === 'traumatologia'
                        ? 'border-teal-600 bg-teal-50/70 ring-2 ring-teal-600/20'
                        : 'border-slate-200 hover:border-teal-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
                      <Activity className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-purple-950">Traumatología & Adultos</p>
                      <p className="text-[11px] text-slate-500">Espalda, articulaciones, lesiones</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Datos de contacto */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-purple-700" />
                    <span>Nombre completo *</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ej. María García"
                    className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-teal-600" />
                    <span>Teléfono móvil (WhatsApp) *</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Ej. 600 123 456"
                    className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Correo y Fecha preferida */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-purple-700" />
                    <span>Correo electrónico (opcional)</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="maria@correo.com"
                    className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-teal-600" />
                    <span>Día preferido</span>
                  </label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-600 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Franja Horaria */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Franja horaria predilecta</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, preferredTime: 'manana' })}
                    className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.preferredTime === 'manana'
                        ? 'bg-purple-900 text-white border-purple-900'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Mañanas (09:00 - 14:00)
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, preferredTime: 'tarde' })}
                    className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                      formData.preferredTime === 'tarde'
                        ? 'bg-purple-900 text-white border-purple-900'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Tardes (15:30 - 20:30)
                  </button>
                </div>
              </div>

              {/* Breve descripción de síntomas */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  ¿Qué te ocurre o qué necesita tu bebé? (Opcional)
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Cuéntanos brevemente qué sientes o qué te preocupa..."
                  className="w-full px-3.5 py-2 text-sm bg-neutral-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all resize-none"
                />
              </div>

              {/* Botón de Enviar */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-4 px-6 text-sm sm:text-base font-black tracking-wide text-white uppercase bg-gradient-to-r from-purple-800 to-teal-600 hover:from-purple-900 hover:to-teal-700 rounded-xl shadow-lg shadow-purple-900/20 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98"
                >
                  <Send className="w-4 h-4" />
                  <span>Confirmar Solicitud de Cita</span>
                </button>
                <p className="text-[11px] text-center text-slate-500 mt-2">
                  🔒 Te contactaremos en menos de 2 horas laborables para confirmar la hora exacta.
                </p>
              </div>

            </form>
          ) : (
            /* Pantalla de Éxito / Confirmación */
            <div className="text-center py-4 space-y-5">
              <div className="w-16 h-16 rounded-full bg-teal-100 text-teal-700 mx-auto flex items-center justify-center shadow-inner">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-2">
                <h4 className="text-2xl font-black text-purple-950">
                  ¡Gracias, {formData.name || 'Paciente'}!
                </h4>
                <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                  Hemos recibido tu solicitud de valoración clínica para{' '}
                  <strong className="text-purple-900">
                    {formData.service === 'pediatria' ? 'Fisioterapia Pediátrica' : 'Traumatología & Adultos'}
                  </strong>.
                </p>
              </div>

              {/* Tarjeta de Resumen */}
              <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-4 max-w-sm mx-auto text-left text-xs space-y-1.5 text-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-500">Teléfono:</span>
                  <span className="font-semibold text-purple-950">{formData.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Preferencia:</span>
                  <span className="font-semibold text-purple-950">
                    {formData.preferredDate || 'Lo antes posible'} · {formData.preferredTime === 'manana' ? 'Mañana' : 'Tarde'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Duración:</span>
                  <span className="font-semibold text-teal-700">50-60 min individual</span>
                </div>
              </div>

              {/* Botón WhatsApp de Acción Directa */}
              <div className="space-y-3 pt-2">
                <a
                  href={generateWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-5 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Enviar Confirmación Directa por WhatsApp</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    setIsSubmitted(false);
                    onClose();
                  }}
                  className="text-xs font-semibold text-slate-500 hover:text-purple-900 transition-colors"
                >
                  Cerrar y volver a la página
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
