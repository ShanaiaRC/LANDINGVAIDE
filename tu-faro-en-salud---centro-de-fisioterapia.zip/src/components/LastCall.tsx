import React from 'react';
import { 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  Phone, 
  MessageCircle, 
  Sparkles, 
  Calendar 
} from 'lucide-react';

interface LastCallProps {
  onOpenBooking: () => void;
  phone: string;
  whatsapp: string;
  ctaText?: string;
}

export const LastCall: React.FC<LastCallProps> = ({ 
  onOpenBooking, 
  phone, 
  whatsapp, 
  ctaText = "TU MOMENTO ES AHORA." 
}) => {
  return (
    <section id="contacto" className="relative py-20 lg:py-28 bg-slate-950 text-white overflow-hidden">
      {/* Decorative radial gradients for high-end dark finish */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-gradient-to-b from-purple-800/25 via-teal-500/15 to-transparent blur-3xl rounded-full"
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute bottom-0 right-0 w-80 h-80 bg-teal-600/10 blur-3xl rounded-full"
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Subtle urgency pill badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-900/80 border border-purple-700/60 text-teal-300 text-xs font-bold uppercase tracking-wider mb-6">
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Agenda Semanal Limitada</span>
          <span className="text-purple-400">·</span>
          <span className="text-purple-200 normal-case font-normal">Máximo 6 pacientes por jornada para trato 1 a 1</span>
        </div>

        {/* Título que refuerce la oferta */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-6 leading-tight text-balance">
          No Pospongas Tu Bienestar Ni El De Tu Familia
        </h2>

        {/* Subtítulo reforzando la oferta */}
        <p className="text-base sm:text-lg lg:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed mb-10 text-balance font-normal">
          El dolor crónico y las molestias de tu pequeño no mejoran esperando. 
          Da el paso hoy y reserva tu <span className="text-teal-300 font-semibold">sesión individualizada de 50-60 minutos</span> con ecografía diagnóstica y terapia manual experta.
        </p>

        {/* Botón CTA Final llamativo */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <button
            onClick={onOpenBooking}
            type="button"
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-3 px-10 py-5 text-lg sm:text-xl font-black tracking-wider text-white uppercase bg-gradient-to-r from-purple-700 via-teal-600 to-teal-500 hover:from-purple-800 hover:via-teal-700 hover:to-teal-600 rounded-xl shadow-2xl shadow-teal-500/20 hover:shadow-teal-400/30 transition-all duration-200 active:scale-98 cursor-pointer focus:outline-hidden focus-visible:ring-4 focus-visible:ring-teal-400"
          >
            <Calendar className="w-6 h-6 text-teal-200" />
            <span>{ctaText}</span>
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1.5 transition-transform" />
          </button>
        </div>

        {/* Vías directas de contacto rápido */}
        <div className="pt-8 border-t border-slate-800/80 max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
          
          <a 
            href={`https://wa.me/${whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('Hola, me gustaría solicitar cita o información en Tu Faro en Salud.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-teal-500/60 hover:bg-slate-900 transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">¿Prefieres escribirnos?</p>
              <p className="text-sm font-bold text-white group-hover:text-teal-300 transition-colors">Chat Directo por WhatsApp</p>
            </div>
          </a>

          <a 
            href={`tel:${phone.replace(/\s+/g, '')}`}
            className="flex items-center gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-purple-500/60 hover:bg-slate-900 transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Atención Telefónica</p>
              <p className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors tabular-nums">{phone}</p>
            </div>
          </a>

        </div>

        {/* Garantías de tranquilidad */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-teal-400" />
            <span>Cancelación o reprogramación gratuita hasta 24h antes</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-teal-400" />
            <span>Confirmación inmediata de tu horario</span>
          </div>
        </div>

      </div>
    </section>
  );
};
