import React from 'react';
import { 
  Baby, 
  ActivitySquare, 
  Sparkle, 
  ArrowRight, 
  Check, 
  Sparkles 
} from 'lucide-react';

interface BenefitsProps {
  onOpenBooking: () => void;
  ctaText?: string;
}

export const Benefits: React.FC<BenefitsProps> = ({ 
  onOpenBooking, 
  ctaText = "TU MOMENTO ES AHORA." 
}) => {
  const benefitsList = [
    {
      id: 'pediatria',
      title: 'Fisioterapia Pediátrica Especializada',
      subtitle: 'El cuidado más dulce y certero para tu bebé',
      icon: Baby,
      badge: 'Especialidad Clínica',
      colorTheme: 'purple',
      description: 
        'Tratamiento suave, indoloro y respetuoso para las afecciones más frecuentes de los primeros meses y la infancia. Devolvemos la tranquilidad a tu hogar.',
      keyPoints: [
        'Cólicos del lactante, gases y reflujo',
        'Tortícolis congénita y plagiocefalias posturales',
        'Estimulación psicomotriz y desarrollo motor',
        'Fisioterapia respiratoria para mocos y bronquiolitis'
      ]
    },
    {
      id: 'traumatologia',
      title: 'Traumatología y Rehabilitación Activa',
      subtitle: 'Vuelve a moverte sin dolor ni limitaciones',
      icon: ActivitySquare,
      badge: 'Recuperación Rápida',
      colorTheme: 'teal',
      description: 
        'Diagnóstico preciso y terapia manual orientada a resolver el origen del dolor, restaurar la movilidad articular y acelerar tu retorno a la vida activa o deportiva.',
      keyPoints: [
        'Dolores de espalda: lumbalgias, cervicalgias y ciáticas',
        'Lesiones articulares: hombro, rodilla, cadera y tobillo',
        'Tendinopatías, roturas fibrilares y esguinces',
        'Rehabilitación integral post-quirúrgica y fracturas'
      ]
    },
    {
      id: 'readaptacion',
      title: 'Readaptación y Prevención Duradera',
      subtitle: 'Consolida tu bienestar sin recaídas futuras',
      icon: Sparkle,
      badge: 'Salud a Largo Plazo',
      colorTheme: 'purple-teal',
      description: 
        'No nos conformamos con tapar los síntomas. Diseñamos un programa individualizado de ejercicio terapéutico y corrección biomecánica para que no vuelvas a recaer.',
      keyPoints: [
        'Ejercicio terapéutico guiado y reeducación funcional',
        'Pautas ergonómicas adaptadas a tu trabajo y rutina',
        'Fortalecimiento progresivo y control motor',
        'Seguimiento cercano y resolución de dudas continua'
      ]
    }
  ];

  return (
    <section id="beneficios" className="py-16 lg:py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Encabezado de la sección */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-teal-700 tracking-wider uppercase px-3 py-1 bg-teal-50 border border-teal-200/80 rounded-md">
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            <span>Nuestras Especialidades de Éxito</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-purple-950 tracking-tight text-balance">
            Soluciones Especializadas para Cada Etapa de tu Vida
          </h2>

          <p className="text-base sm:text-lg text-slate-600 leading-relaxed text-balance">
            Combinamos la máxima evidencia científica, la tecnología más avanzada y un trato cercano y empático para lograr que tú y tu familia volváis a disfrutar de cada día con total plenitud.
          </p>
        </div>

        {/* Grid de 3 columnas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {benefitsList.map((item) => {
            const Icon = item.icon;
            const isTeal = item.colorTheme === 'teal';
            const isMixed = item.colorTheme === 'purple-teal';

            return (
              <div 
                key={item.id}
                className="flex flex-col justify-between bg-neutral-50/70 rounded-2xl p-7 border border-slate-200/80 hover:border-purple-300 hover:shadow-xl hover:bg-white transition-all duration-300 group"
              >
                <div>
                  {/* Icono y Badge */}
                  <div className="flex items-center justify-between gap-4 mb-6">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center transition-transform group-hover:scale-105 duration-200 ${
                      isTeal 
                        ? 'bg-teal-100 text-teal-800' 
                        : isMixed 
                          ? 'bg-gradient-to-tr from-purple-100 to-teal-100 text-purple-900' 
                          : 'bg-purple-100 text-purple-800'
                    }`}>
                      <Icon className="w-7 h-7" />
                    </div>

                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {item.badge}
                    </span>
                  </div>

                  {/* Título y subtítulo */}
                  <h3 className="text-xl font-bold text-purple-950 mb-2 group-hover:text-purple-800 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs font-semibold text-teal-700 uppercase tracking-wide mb-4">
                    {item.subtitle}
                  </p>

                  {/* Descripción breve */}
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {item.description}
                  </p>

                  {/* Lista de puntos clave */}
                  <ul className="space-y-2.5 pt-2 border-t border-slate-200/60 text-xs sm:text-sm text-slate-700 mb-6">
                    {item.keyPoints.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t border-slate-200/50">
                  <button
                    onClick={onOpenBooking}
                    type="button"
                    className="w-full py-2.5 px-4 text-xs font-bold text-purple-900 bg-white hover:bg-purple-50 rounded-lg border border-purple-200 hover:border-purple-300 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>Consultar este tratamiento</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Debajo: Botón CTA centrado */}
        <div className="mt-14 text-center">
          <button
            onClick={onOpenBooking}
            type="button"
            className="group inline-flex items-center justify-center gap-3 px-8 sm:px-10 py-4 text-base sm:text-lg font-black tracking-wide text-white uppercase bg-gradient-to-r from-purple-800 via-purple-700 to-teal-600 hover:from-purple-900 hover:via-purple-800 hover:to-teal-700 rounded-xl shadow-lg shadow-purple-900/20 hover:shadow-xl hover:shadow-teal-700/25 transition-all duration-200 active:scale-98 cursor-pointer focus:outline-hidden focus-visible:ring-4 focus-visible:ring-teal-400"
          >
            <span>{ctaText}</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          <p className="text-xs text-slate-500 mt-3">
            Plazas limitadas por semana · Trato 1 a 1 sin esperas
          </p>
        </div>

      </div>
    </section>
  );
};
