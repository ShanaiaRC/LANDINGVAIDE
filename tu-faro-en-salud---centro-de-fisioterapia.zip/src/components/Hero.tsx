import React from 'react';
import { 
  ArrowRight, 
  ShieldCheck, 
  HeartHandshake, 
  Activity, 
  Sparkles, 
  Clock, 
  Award,
  CheckCircle2
} from 'lucide-react';
import heroImg from '../assets/images/hero_physiotherapy_clinic_1792420758989.jpg';

interface HeroProps {
  onOpenBooking: () => void;
  ctaText?: string;
}

export const Hero: React.FC<HeroProps> = ({ 
  onOpenBooking, 
  ctaText = "TU MOMENTO ES AHORA." 
}) => {
  return (
    <section id="top" className="relative overflow-hidden pt-8 pb-14 lg:pt-14 lg:pb-20 bg-gradient-to-b from-purple-50/60 via-white to-neutral-50/80">
      {/* Subtle background ambient gradients */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-[800px] h-[360px] bg-gradient-to-tr from-purple-200/35 via-teal-200/25 to-transparent blur-3xl rounded-full -z-10"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main 2-column Hero split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Lado izquierdo: Título principal grande, subtítulo claro y botón CTA llamativo */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline / Subtítulo claro */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-purple-100/70 border border-purple-200/60 text-purple-900 text-xs sm:text-sm font-bold tracking-wide uppercase">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>A TU ALCANCE</span>
              <span className="text-purple-300">·</span>
              <span className="text-teal-700 font-semibold normal-case">Fisioterapia Especializada</span>
            </div>

            {/* Título principal grande */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-purple-950 leading-[1.08] text-balance">
              TU FARO <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-800 via-teal-600 to-teal-500">
                EN SALUD
              </span>
            </h1>

            {/* Subtítulo descriptivo y propósito */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-700 leading-relaxed max-w-2xl text-balance font-normal">
              Especialistas en <strong className="font-semibold text-purple-900">Fisioterapia Pediátrica</strong> y <strong className="font-semibold text-purple-900">Traumatología</strong>. 
              Aliviamos el dolor, recuperamos tu movilidad y cuidamos el desarrollo de los más pequeños en un entorno seguro, humano y 100% individualizado.
            </p>

            {/* Bloque CTA llamativo */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                type="button"
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 text-base sm:text-lg font-black tracking-wide text-white uppercase bg-gradient-to-r from-purple-800 via-purple-700 to-teal-600 hover:from-purple-900 hover:via-purple-800 hover:to-teal-700 rounded-xl shadow-lg shadow-purple-900/20 hover:shadow-xl hover:shadow-teal-700/25 transition-all duration-200 active:scale-98 cursor-pointer focus:outline-hidden focus-visible:ring-4 focus-visible:ring-teal-400"
              >
                <span>{ctaText}</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-600 px-1">
                <Clock className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Sesiones completas de 50-60 min sin esperas</span>
              </div>
            </div>

            {/* Micro badges de confianza rápida */}
            <div className="pt-3 border-t border-purple-100/80 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-600">
              <div className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Col. Profesional Oficial</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Atención clínica 1 a 1</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Tratamiento sin dolor innecesario</span>
              </div>
            </div>

          </div>

          {/* Lado derecho: Espacio reservado para imagen o ilustración relevante */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Decorative colored backdrop glow */}
              <div 
                aria-hidden="true" 
                className="absolute -inset-2 bg-gradient-to-tr from-purple-600/25 to-teal-400/25 rounded-3xl blur-xl transform -rotate-1"
              />

              {/* Main image container */}
              <div className="relative rounded-2xl overflow-hidden border border-purple-200/80 bg-white shadow-xl">
                <img 
                  src={heroImg} 
                  alt="Sesión de fisioterapia y rehabilitación personalizada en Tu Faro en Salud" 
                  className="w-full h-auto max-h-[460px] object-cover object-center"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />

                {/* Subtle overlay float badge */}
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-xl border border-teal-100 shadow-md flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700 shrink-0">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-purple-950 uppercase tracking-wider">Centro Homologado</p>
                      <p className="text-xs text-slate-600">Especialistas en Pediatría & Traumatología</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="inline-block text-xs font-bold text-teal-700 bg-teal-50 px-2 py-1 rounded-md border border-teal-200">
                      100% Personalizado
                    </span>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Debajo: Lista de 3 puntos destacados (beneficios rápidos requeridos: COMPROMISO, RESULTADOS, ACOMPAÑAMIENTO) */}
        <div className="mt-14 lg:mt-18 pt-8 border-t border-purple-200/60">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            
            {/* Beneficio 1: COMPROMISO */}
            <div className="bg-white rounded-xl p-6 border border-purple-100 shadow-xs hover:border-purple-300 hover:shadow-md transition-all">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-100/80 text-purple-800 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">Pilar 01</span>
                    <span className="text-slate-300">·</span>
                    <h2 className="text-lg font-extrabold text-purple-950">COMPROMISO</h2>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Dedicación absoluta en cada sesión. Evaluamos minuciosamente tu caso sin prisas ni cabinas múltiples, respetando tus tiempos y necesidades.
                  </p>
                </div>
              </div>
            </div>

            {/* Beneficio 2: RESULTADOS */}
            <div className="bg-white rounded-xl p-6 border border-teal-100 shadow-xs hover:border-teal-300 hover:shadow-md transition-all">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-teal-100/80 text-teal-800 flex items-center justify-center shrink-0">
                  <Activity className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-purple-700 uppercase tracking-wider">Pilar 02</span>
                    <span className="text-slate-300">·</span>
                    <h2 className="text-lg font-extrabold text-purple-950">RESULTADOS</h2>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Alivio medible del dolor y recuperación de la movilidad. Aplicamos las técnicas con mayor evidencia científica para acelerar tu bienestar real.
                  </p>
                </div>
              </div>
            </div>

            {/* Beneficio 3: ACOMPAÑAMIENTO */}
            <div className="bg-white rounded-xl p-6 border border-purple-100 shadow-xs hover:border-purple-300 hover:shadow-md transition-all">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-100 to-teal-100 text-purple-900 flex items-center justify-center shrink-0">
                  <HeartHandshake className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">Pilar 03</span>
                    <span className="text-slate-300">·</span>
                    <h2 className="text-lg font-extrabold text-purple-950">ACOMPAÑAMIENTO</h2>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Te guiamos dentro y fuera de consulta. Pautas de ejercicios para casa y asesoramiento cercano a familias en cada etapa de la recuperación.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
