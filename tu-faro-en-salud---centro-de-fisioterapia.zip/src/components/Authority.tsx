import React from 'react';
import { 
  Award, 
  BadgeCheck, 
  GraduationCap, 
  Stethoscope, 
  HeartHandshake, 
  Building2 
} from 'lucide-react';

export const Authority: React.FC = () => {
  const metrics = [
    {
      value: '+12',
      unit: 'Años',
      label: 'De Experiencia Clínica Especializada',
      description: 'Práctica continua en traumatología y pediatría'
    },
    {
      value: '+3.800',
      unit: 'Casos',
      label: 'Pacientes y Bebés Tratados',
      description: 'Resultados clínicos avalados y contrastados'
    },
    {
      value: '98.4%',
      unit: 'Éxito',
      label: 'Satisfacción y Alta Médica',
      description: 'Recuperaciones duraderas sin recaídas'
    },
    {
      value: '100%',
      unit: 'Exclusivo',
      label: 'Tiempo Dedicado a Cada Paciente',
      description: '50-60 min completos por cita con tu fisio'
    }
  ];

  const credentials = [
    {
      icon: BadgeCheck,
      title: 'Fisioterapeuta Colegiada Oficial',
      detail: 'Colegiada nº 4.821 · Ilustre Colegio de Fisioterapeutas'
    },
    {
      icon: GraduationCap,
      title: 'Máster en Fisioterapia Pediátrica',
      detail: 'Formación universitaria oficial de posgrado'
    },
    {
      icon: Stethoscope,
      title: 'Terapia Manual y Ecografía Clínica',
      detail: 'Diagnóstico ecográfico y terapia ortopédica avanzada'
    },
    {
      icon: Building2,
      title: 'Centro Sanitario Autorizado',
      detail: 'Instalaciones homologadas por la Consejería de Sanidad'
    }
  ];

  return (
    <section id="autoridad" className="relative py-16 lg:py-20 bg-purple-950 text-white overflow-hidden">
      {/* Background soft teal glow accent */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-teal-500/10 blur-3xl rounded-full"
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -bottom-10 right-0 w-80 h-80 bg-purple-600/20 blur-3xl rounded-full"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Frase de autoridad y encabezado */}
        <div className="max-w-4xl mx-auto text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-teal-900/60 border border-teal-500/30 text-teal-300 text-xs font-bold tracking-wider uppercase">
            <Award className="w-3.5 h-3.5 text-teal-400" />
            <span>Rigurosidad Clínica y Empatía Humana</span>
          </div>

          <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-snug text-balance">
            &ldquo;La fisioterapia de vanguardia no es solo quitar el dolor; es devolver la serenidad a tu familia con ciencia, tiempo y dedicación real.&rdquo;
          </blockquote>

          <p className="text-sm sm:text-base text-purple-200/90 max-w-2xl mx-auto font-light leading-relaxed">
            Un faro que te orienta hacia la salud duradera. Sin protocolos estándar impersonales, sin máquinas desatendidas y con la tranquilidad de estar en manos expertas tituladas.
          </p>
        </div>

        {/* Métricas destacadas en bloque horizontal */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 pb-12 border-b border-purple-800/80">
          {metrics.map((m, idx) => (
            <div 
              key={idx} 
              className="bg-purple-900/50 backdrop-blur-xs rounded-xl p-5 border border-purple-800/70 hover:border-teal-400/40 transition-colors"
            >
              <div className="flex items-baseline gap-2 mb-1">
                <span className="text-3xl sm:text-4xl font-black text-teal-300 tracking-tight font-mono tabular-nums">
                  {m.value}
                </span>
                <span className="text-xs font-semibold text-purple-300 uppercase">
                  {m.unit}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white mb-1">
                {m.label}
              </h4>
              <p className="text-xs text-purple-200/70 leading-relaxed">
                {m.description}
              </p>
            </div>
          ))}
        </div>

        {/* Bloque de acreditaciones y logotipos de confianza */}
        <div className="mt-10">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-purple-300/80 mb-6">
            Garantías Clínicas y Avales Sanitarios
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {credentials.map((cred, idx) => {
              const Icon = cred.icon;
              return (
                <div 
                  key={idx}
                  className="flex items-center gap-3.5 p-3.5 rounded-lg bg-purple-900/30 border border-purple-800/50"
                >
                  <div className="w-9 h-9 rounded-md bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">
                      {cred.title}
                    </p>
                    <p className="text-[11px] text-purple-200/70 truncate">
                      {cred.detail}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
