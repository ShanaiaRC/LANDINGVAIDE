import React from 'react';
import { Star, Quote, CheckCircle } from 'lucide-react';
import traumaImg from '../assets/images/testimonial_patient_trauma_1792420760386.jpg';
import pediatricImg from '../assets/images/testimonial_mother_child_1792420760234.jpg';

export const SocialProof: React.FC = () => {
  const testimonials = [
    {
      id: 'trauma',
      name: 'Carlos Mendoza',
      ageOrDetail: '34 años · Paciente de Traumatología y Readaptación',
      treatment: 'Rotura meniscal y dolor lumbar crónico',
      outcome: 'Recuperación funcional total en 6 semanas',
      photo: traumaImg,
      opinion: 
        'Llegué desanimado tras meses con un dolor punzante en la rodilla y lumbar que me impedía jugar con mis hijos e ir a correr. Desde el primer día noté la diferencia: aquí no te enchufan a una máquina y se van, sino que te evalúan a fondo con ecografía, terapia manual y un plan milimétrico. En pocas semanas volví a entrenar sin molestias. Cumplieron con su compromiso y con creces.',
    },
    {
      id: 'pediatria',
      name: 'Elena Torres y el pequeño Lucas',
      ageOrDetail: 'Madre de Lucas (4 meses) · Fisioterapia Pediátrica',
      treatment: 'Cólicos severos del lactante y plagiocefalia',
      outcome: 'Alivio del llanto y corrección craneal completa',
      photo: pediatricImg,
      opinion: 
        'Las noches con Lucas eran una angustia continua por los cólicos y nos preocupaba mucho la asimetría en su cabecita. En Tu Faro en Salud encontramos una delicadeza y conocimiento que nos devolvió la paz. Tras la segunda sesión, Lucas dormía plácidamente y nosotros aprendimos cómo cuidarlo en casa sin miedo. Fueron una auténtica bendición y un faro de luz en nuestro postparto.',
    }
  ];

  return (
    <section id="testimonios" className="py-16 lg:py-24 bg-gradient-to-b from-white to-purple-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Encabezado */}
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-700 uppercase tracking-widest px-3 py-1 bg-teal-50 border border-teal-200 rounded-md">
            <span>Prueba Social y Casos Reales</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-purple-950 tracking-tight text-balance">
            Historias que Nos Llenan de Orgullo
          </h2>

          <p className="text-sm sm:text-base text-slate-600">
            Personas y familias como la tuya que ya dieron el paso y han recuperado su bienestar.
          </p>
        </div>

        {/* Dos testimonios destacados con foto circular */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 max-w-5xl mx-auto">
          {testimonials.map((t) => (
            <div 
              key={t.id}
              className="relative flex flex-col justify-between bg-white rounded-2xl p-7 lg:p-8 border border-purple-100/90 shadow-md hover:shadow-xl hover:border-teal-300 transition-all duration-300"
            >
              {/* Top Quote Icon */}
              <div className="absolute top-6 right-6 text-purple-100 pointer-events-none">
                <Quote className="w-12 h-12 rotate-180" />
              </div>

              <div>
                {/* 5 Stars */}
                <div className="flex items-center gap-1 text-amber-400 mb-5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="ml-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Opinión Verificada
                  </span>
                </div>

                {/* Testimonial text */}
                <p className="text-sm sm:text-base text-slate-700 leading-relaxed italic mb-7 relative z-10">
                  &ldquo;{t.opinion}&rdquo;
                </p>
              </div>

              {/* Patient info with circular photo */}
              <div className="pt-5 border-t border-slate-100 flex items-center gap-4">
                {/* Foto circular requerida */}
                <div className="relative shrink-0">
                  <img 
                    src={t.photo} 
                    alt={`Foto de testimonio de ${t.name}`}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover border-2 border-teal-500 shadow-md ring-4 ring-purple-100/60"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-teal-600 text-white rounded-full p-1 shadow-xs">
                    <CheckCircle className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Name, role and concrete result */}
                <div className="min-w-0">
                  <h3 className="text-base sm:text-lg font-bold text-purple-950 truncate">
                    {t.name}
                  </h3>
                  <p className="text-xs font-medium text-slate-500 truncate">
                    {t.ageOrDetail}
                  </p>
                  <p className="text-xs font-semibold text-teal-700 mt-0.5 truncate">
                    Resultado: {t.outcome}
                  </p>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Global rating banner */}
        <div className="mt-12 text-center flex flex-wrap items-center justify-center gap-3 text-xs sm:text-sm text-slate-600 font-medium">
          <div className="flex items-center gap-1 text-amber-500 font-bold">
            <span>5.0</span>
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              ))}
            </div>
          </div>
          <span className="text-slate-300">·</span>
          <span>Basado en más de 250 reseñas contrastadas en Google y Doctoralia</span>
        </div>

      </div>
    </section>
  );
};
