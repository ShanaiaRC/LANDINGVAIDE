export interface BookingData {
  service: 'pediatria' | 'traumatologia' | 'general';
  name: string;
  phone: string;
  email: string;
  preferredDate: string;
  preferredTime: 'manana' | 'tarde';
  notes: string;
}

export interface ClinicConfig {
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  customDestinationUrl: string;
}

export const DEFAULT_CLINIC_CONFIG: ClinicConfig = {
  phone: '+34 912 345 678',
  whatsapp: '+34600123456',
  email: 'citas@tufaroensalud.com',
  address: 'Calle Salud y Bienestar, 24, Bajo',
  city: 'Madrid / Tu Ciudad',
  customDestinationUrl: '', // Si se especifica, el CTA puede redirigir aquí o abrir el formulario
};
