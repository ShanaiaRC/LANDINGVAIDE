/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Benefits } from './components/Benefits';
import { Authority } from './components/Authority';
import { SocialProof } from './components/SocialProof';
import { LastCall } from './components/LastCall';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { DEFAULT_CLINIC_CONFIG, ClinicConfig } from './types';

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [clinicConfig, setClinicConfig] = useState<ClinicConfig>(DEFAULT_CLINIC_CONFIG);

  const handleOpenBooking = () => {
    // If the owner configured an external payment or scheduling link, we can support redirect or open modal
    if (clinicConfig.customDestinationUrl && clinicConfig.customDestinationUrl.trim() !== '') {
      window.open(clinicConfig.customDestinationUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    setIsModalOpen(true);
  };

  const handleCloseBooking = () => {
    setIsModalOpen(false);
  };

  const handleUpdateConfig = (newConfig: ClinicConfig) => {
    setClinicConfig(newConfig);
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-slate-800 antialiased selection:bg-teal-500 selection:text-white">
      
      {/* 1. Header / Top Bar Contract */}
      <Navbar 
        onOpenBooking={handleOpenBooking}
        phone={clinicConfig.phone}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero 
          onOpenBooking={handleOpenBooking}
          ctaText="TU MOMENTO ES AHORA."
        />

        {/* 3. Sección de Beneficios */}
        <Benefits 
          onOpenBooking={handleOpenBooking}
          ctaText="TU MOMENTO ES AHORA."
        />

        {/* 4. Sección de Autoridad */}
        <Authority />

        {/* 5. Sección de Prueba Social */}
        <SocialProof />

        {/* 6. Sección Final (Last Call) */}
        <LastCall 
          onOpenBooking={handleOpenBooking}
          phone={clinicConfig.phone}
          whatsapp={clinicConfig.whatsapp}
          ctaText="TU MOMENTO ES AHORA."
        />
      </main>

      {/* 7. Footer */}
      <Footer 
        phone={clinicConfig.phone}
        email={clinicConfig.email}
        address={clinicConfig.address}
        city={clinicConfig.city}
        onOpenBooking={handleOpenBooking}
      />

      {/* Interactive Booking & Payment Modal */}
      <BookingModal 
        isOpen={isModalOpen}
        onClose={handleCloseBooking}
        config={clinicConfig}
        onUpdateConfig={handleUpdateConfig}
      />

    </div>
  );
}
